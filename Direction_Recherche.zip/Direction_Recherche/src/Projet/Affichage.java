package Projet;

import java.awt.Color;
import Projet.StdDraw3D.Shape;

public class Affichage {

	private static Volume Conteneur = new Volume(0,0,0,100,500,100);
	private static int ScaleXmin = (int) -Conteneur.getLargeur();
	private static int ScaleXmax = (int) Conteneur.getLargeur();

	public static void main(String[] args) throws InterruptedException {
		
		// D�finition de l'echelle de la fenetre
        StdDraw3D.setScale(ScaleXmin,ScaleXmax);
        
        // Chargement des limites du conteneur 
		Shape Sol = Afficher_Volume(new Volume(0,0,0,Conteneur.getLargeur(),0,Conteneur.getProfondeur()), 255);
		Sol.setColor(Color.WHITE, 255);
		Shape MurG = Afficher_Volume(new Volume(0,0,0,0,Conteneur.getHauteur(),Conteneur.getProfondeur()), 255);
		MurG.setColor(Color.WHITE, 255);
		Shape MurD = Afficher_Volume(new Volume(Conteneur.getLargeur(),0,0,0,Conteneur.getHauteur(),Conteneur.getProfondeur()), 255);
		MurD.setColor(Color.WHITE, 255);  
		
        // G�n�ration des volumes � placer
        //Volume[] v = Volume.generateurVolume(1000, 1, 55, 1, 45, 1, 35); // Pas bien avec conteneur (500, 500 ,500)
		Volume[] v = Volume.Read_from_file("C:\\Users\\ssece\\Documents\\test");
        System.out.println("ddddd" + v.length);

        //Volume[] v = Volume.generateurVolume(1000, 1, 50, 1, 50, 1, 50); //Pas bien avec conteneur (250, 250, 250) !
        
        // R�cup�ration des volumes qui ont �t� plac� avec succ�s
		Volume[] Place = MaxRects.MaxRectsRun(Conteneur, v, "lph");
		
		// Chargement des volumes plac�s
        for (Volume v_place : Place) {
        	Shape S = Afficher_Volume(v_place, 200);	
        	//System.out.println(v_place.toString());
        }
        
        
        //System.out.println(Volume.Compter_places(v));
        
        // Affichage du r�sultat obtenu
        StdDraw3D.finished();
	}
	
	public static Shape Afficher_Volume (Volume v, int alpha) {
		// Changement de rep�re et chargement du volume
		Shape S = StdDraw3D.box(	v.getX()+v.getLargeur()/2-Conteneur.getLargeur()/2, 
									v.getY()+v.getHauteur()/2-Conteneur.getHauteur()/2, 
									v.getZ()+v.getProfondeur()/2-Conteneur.getProfondeur()/2, 
									v.getLargeur()/2, 
									v.getHauteur()/2, 
									v.getProfondeur()/2);
		
		// Selection d'une couleur al�atoire pour le volume actuel
		S.setColor(StdDraw3D.randomColor(), alpha);
		
		return S;
	}
}
