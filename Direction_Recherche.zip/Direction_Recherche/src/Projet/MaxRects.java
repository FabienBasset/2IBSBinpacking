package Projet;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class MaxRects {

	public MaxRects() {

	}

	public static Volume[] MaxRectsRun(Volume container, Volume[] volumes, String pref_placement) {
		List<Volume> dispo = new LinkedList<Volume>();
		List<Volume> place = new LinkedList<Volume>();
		dispo.add(container);
		volumes = Volume.Tri_dimension(volumes, "vlhp", "0");
		for (Volume v : volumes) {
			if (dispo.size() == 0) {
				System.out.println("Plus de place. Arr�t.");
				return (place.toArray(new Volume[place.size()]));
			}

			dispo = new LinkedList<Volume>(
					Arrays.asList(Volume.Tri_dimension(dispo.toArray(new Volume[dispo.size()]), "v", "0")));
			dispo = Volume.RegrouperVolumes(dispo.toArray(new Volume[dispo.size()]));

			boolean rentre = false, rentre2;

			for (int i = 0; i < dispo.size() && rentre == false; i++) {
				rentre = v.rentre_dans(dispo.get(i), pref_placement);
				if (rentre) {
					v.setPlace(true);
					Volume container_choisi = dispo.get(i).clone();
					v.setX((int) container_choisi.getX());
					v.setY((int) container_choisi.getY());
					v.setZ((int) container_choisi.getZ());
					place.add(v.clone());

					Volume[] new_libres = Volume.Decouper_Volume_libre(container_choisi, v);
					dispo.remove(i);
					//List<Volume> dispo_tmp = new LinkedList<Volume>(dispo);

					 for(Volume v2:new_libres)
						 dispo.add(v2.clone());

					/*if (new_libres.length > 0)
						if (dispo.size() == 0)
							for (Volume v2 : new_libres) 
								dispo.add(v2.clone());
						else
							for (Volume v2 : new_libres)
							{
								rentre2 = false;
								for (Volume volume : dispo_tmp)
									if (!rentre2 && !v2.clone().rentre_dans(volume, pref_placement)) {
										dispo.add(v2.clone());
										rentre2 = true;
									}

							}*/

				} else {
					// System.out.println("Impossible de rentrer le volume : " + v.toString());
				}

			}
		}

		System.out.println("Tous les volumes ont �t� trait�s.");
		System.out.println(place.size());
		// for(Volume v2:dispo)
		// System.out.println("DISPO : " + v2.toString());
		// System.out.println();

		return (place.toArray(new Volume[place.size()]));

	}
}
