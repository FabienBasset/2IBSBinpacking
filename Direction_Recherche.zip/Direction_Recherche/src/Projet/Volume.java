package Projet;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Volume implements Cloneable, java.io.Serializable {
	private double x;
	private double y;
	private double z;
	private double hauteur;
	private double largeur;
	private double profondeur;
	private static int id_next = 0;
	private int id;

	private boolean place;

	public boolean isPlace() {
		return place;
	}

	public static void to_file(Volume[] volumes, String file_path) {
		ObjectOutputStream oos = null;
		final FileOutputStream fichier;
		
		try {
			fichier = new FileOutputStream(file_path);
			oos = new ObjectOutputStream(fichier);
			for(Volume volume : volumes)
			{
				oos.writeObject(volume);
				oos.flush();
			}
			
		} catch (final java.io.IOException e) {
			e.printStackTrace();
		} finally {
			
			try {
				if (oos != null) {
					oos.flush();
					oos.close();
				}
			} catch (final IOException ex) {
				ex.printStackTrace();
			}
		}

	}
	
	public static Volume[] Read_from_file(String file_path) {
		ObjectInputStream ois = null;

	    try {
	      final FileInputStream fichier = new FileInputStream(file_path);
	      ois = new ObjectInputStream(fichier);
	      List<Volume> volumes = new LinkedList<Volume>();
	      try {
	    	  Volume obj;
	    	  while((obj = (Volume)ois.readObject()) != null)
	    		  volumes.add(obj);
	      }
	      catch(final java.io.IOException e) {
		      return volumes.toArray(new Volume[volumes.size()]);
		      }

	    } catch (final java.io.IOException e) {
	      e.printStackTrace();
	    } catch (final ClassNotFoundException e) {
	      e.printStackTrace();
	    } finally {
	      try {
	        if (ois != null) {
	          ois.close();
	        }
	      } catch (final IOException ex) {
	        ex.printStackTrace();
	      }
	      
	    }
	    return null;
	}
	
	
	public void setPlace(boolean place) {
		this.place = place;
	}

	public Volume(double x, double y, double z, double largeur, double hauteur, double profondeur) {
		this.x = x;
		this.y = y;
		this.hauteur = hauteur;
		this.largeur = largeur;
		this.profondeur = profondeur;
		this.z = z;
		this.id = Volume.id_next++;
		this.place = false;
	}

	public double getSurfaceMax() {
		double a1 = this.hauteur * this.largeur;
		double a2 = this.hauteur * this.profondeur;
		double a3 = this.largeur * this.profondeur;
		if (a1 >= a2 && a1 >= a3)
			return a1;
		else if (a2 >= a1 && a2 >= a3)
			return a2;
		else
			return a3;
	}

	public double getVolume() {
		return this.hauteur * this.largeur * this.profondeur;
	}

	public double getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public double getZ() {
		return z;
	}

	public void setZ(int Z) {
		this.z = Z;
	}

	public double getHauteur() {
		return hauteur;
	}

	public double getLargeur() {
		return largeur;
	}

	public double getProfondeur() {
		return profondeur;
	}

	public int getID() {
		return id;
	}

	public static Volume[] Decouper_Volume_libre(Volume container, Volume object) {
		List<Volume> l = new ArrayList<Volume>();
		if (object.x >= container.x && object.x <= container.x + container.largeur
				&& object.x + object.largeur <= container.x + container.largeur && object.y >= container.y
				&& object.y <= container.y + container.hauteur
				&& object.y + object.hauteur <= container.y + container.hauteur && object.z >= container.z
				&& object.z <= container.z + container.profondeur
				&& object.z + object.profondeur <= container.z + container.profondeur) {
			/* GAUCHE */
			if (object.x - container.x != 0)
				l.add(new Volume(container.x, container.y, container.z, object.x - container.x, container.hauteur,
						object.z - container.z + object.profondeur));

			/* DROITE */
			if (container.largeur - object.largeur - object.x + container.x != 0)
				l.add(new Volume(object.x + object.largeur, container.y, container.z,
						container.largeur - object.largeur - object.x + container.x, container.hauteur,
						object.z - container.z + object.profondeur));

			/* DESSUS */
			if (container.y + container.hauteur != object.y + object.hauteur)
				l.add(new Volume(object.x, object.y + object.hauteur, container.z, object.largeur,
						container.hauteur - object.hauteur - object.y + container.y,
						object.z - container.z + object.profondeur));

			/* DESSOUS */
			if (container.y != object.y)
				l.add(new Volume(object.x, container.y, container.z, object.largeur, object.y - container.y,
						object.z - container.z + object.profondeur));

			/* DEVANT */
			if (object.z != container.z)
				l.add(new Volume(object.x, object.y, container.z, object.largeur, object.hauteur,
						object.z - container.z));

			/* ARRIERE */
			if (object.z + object.profondeur != container.z + container.profondeur)
				l.add(new Volume(container.x, container.y, object.z + object.profondeur, container.largeur,
						container.hauteur, container.profondeur - (object.z - container.z) - object.profondeur));
		} else
			l.add(container);

		return (l.toArray(new Volume[l.size()]));
	}

	public static Volume[] generateurVolume(int nombreObjet, int largeur_min, int largeur_max, int hauteur_min,
			int hauteur_max, int profondeur_min, int profondeur_max) {
		Volume[] volumes = new Volume[nombreObjet];
		Volume v;
		for (int i = 0; i < nombreObjet; i++) {
			v = new Volume(0, 0, 0, (int) (Math.random() * (hauteur_max - hauteur_min) + hauteur_min),
					(int) (Math.random() * (largeur_max - largeur_min) + largeur_min),
					(int) (Math.random() * (profondeur_max - profondeur_min) + profondeur_min));

			volumes[i] = v;
		}
		return (volumes);
	}

	/*
	 * retourne une dimension en fonction d'une lettre. Les lettres x,y,z,l,h,p,s,v
	 * retournent respectivement X,Y,Z,Largeur,Hauteur,Profondeur,SurfaceMax,Volume.
	 * Ces lettres sont utilis�es dans toutes les fonction n�c�ssitant un param�tre
	 * de dimensions. Si une autre lettre ou aucune appara�t, c'est l'ID du volume
	 * qui servira de dimension.
	 */
	private double getDimension(char c) {
		if (c == 'x')
			return x;
		else if (c == 'y')
			return y;
		else if (c == 'z')
			return z;
		else if (c == 's')
			return getSurfaceMax();
		else if (c == 'v')
			return getVolume();
		else if (c == 'l')
			return largeur;
		else if (c == 'h')
			return hauteur;
		else if (c == 'p')
			return profondeur;
		else
			return id;
	}

	private static void Tri_dimension_n(Volume[] volumes, char n, boolean croissant) {
		double check;
		Volume tmp;

		if (croissant) {
			int j, i = 0;
			while (i < volumes.length) {
				j = i + 1;
				check = volumes[i].getDimension(n);
				while (j < volumes.length && volumes[j].getDimension(n) >= check)
					j++;
				if (j < volumes.length) {
					tmp = volumes[i];
					volumes[i] = volumes[j];
					volumes[j] = tmp;
				} else
					i++;
			}
		} else {
			int j, i = 0;
			while (i < volumes.length) {
				j = i + 1;
				check = volumes[i].getDimension(n);
				while (j < volumes.length && volumes[j].getDimension(n) <= check)
					j++;
				if (j < volumes.length) {
					tmp = volumes[i];
					volumes[i] = volumes[j];
					volumes[j] = tmp;
				} else
					i++;
			}
		}

	}

	/* Compte les volumes utilis�s */
	public static int Compter_places(Volume[] volumes) {
		int res = 0;
		for (Volume v : volumes)
			if (v.place)
				res++;
		return res;
	}

	/*
	 * Trier un tableau de volumes suivant ses diff�rentes dimensions. Passer en
	 * param�tres les combinaisons suivantes: x: position X du volume y: position Y
	 * du volume z: position Z du volume l: Largeur du volume h: Hauteur du volume
	 * p: Profondeur du volume s: surface maximum trouv�e dans un volume (face la
	 * plus grande) v: volume du volume default : ID
	 */
	public static Volume[] Tri_dimension(Volume[] volumes, String ordre_dim, String croissant) {
		if (ordre_dim.length() == 0)
			return (volumes);
		String char_croissant = "0";
		Volume[] v = volumes.clone();
		if (croissant.length() == 0 || croissant.charAt(0) != '0') {
			Tri_dimension_n(v, ordre_dim.charAt(0), true);
			char_croissant = "1";
		} else
			Tri_dimension_n(v, ordre_dim.charAt(0), false);

		List<Double> values = new ArrayList<Double>();
		List<List<Volume>> tmp_v = new ArrayList<List<Volume>>();

		for (Volume i : v)
			if (!values.contains(i.getDimension(ordre_dim.charAt(0))))
				values.add(i.getDimension(ordre_dim.charAt(0)));
		for (Double x : values) {
			List<Volume> l = new ArrayList<Volume>();
			for (Volume i : v)
				if (i.getDimension(ordre_dim.charAt(0)) == x)
					l.add(i);
			tmp_v.add(l);
		}

		v = new Volume[volumes.length];
		int j = 0;
		for (List<Volume> l : tmp_v)
			for (Volume i : Tri_dimension((Volume[]) l.toArray(new Volume[l.size()]), ordre_dim.substring(1),
					char_croissant))
				v[j++] = i;

		return (v);
	}

	@Override
	public String toString() {
		return ("ID=" + getID() + "  X=" + getX() + "  Y=" + getY() + "  Z=" + getZ() + "  Largeur=" + getLargeur()
				+ "  Hauteur=" + getHauteur() + "  Profondeur=" + getProfondeur() + "  SurfaceMax=" + getSurfaceMax()
				+ "  Volume=" + getVolume());
	}

	public Volume clone() {
		Volume v = new Volume(x, y, z, largeur, hauteur, profondeur);
		v.setPlace(place);
		return v;
	}

	public void basculer_90_degres_droite() {
		double tmp = largeur;
		largeur = hauteur;
		hauteur = tmp;
	}

	public void basculer_90_degres_avant() {
		double tmp = profondeur;
		profondeur = hauteur;
		hauteur = tmp;
	}

	public void pivoter_90_degres_droite() {
		double tmp = profondeur;
		profondeur = largeur;
		largeur = tmp;
	}

	/*
	 * Renvoie un boolean indiquant si le l'objet rentre dans le Volume volume. Si
	 * oui, la fonction l'oriente afin qu'il puisse rentrer et si possible suivant
	 * les pr�f�rences d'agencement de l'objet via ses dimensions dim_pref
	 */
	public boolean rentre_dans(Volume volume, String dim_pref) {
		for (char dim : dim_pref.toCharArray())
			if (dim_pref.length() != 3 || (dim != 'l' && dim != 'p' && dim != 'h'))
				throw new IllegalArgumentException(
						"Dimension(s) incorrecte(s), dim_pref doit contenir 3 caract�res parmi les lettres l,h et p, correspondantes respectivement aux dimensions de largeur, hauteur et profondeur du volume !");

		boolean res = false;
		double a, b, c;
		String[] possibilities = { "lhp", "lph", "hlp", "hpl", "phl", "plh" };
		List<Volume> v = new ArrayList<Volume>();

		for (String s : possibilities) {
			a = getDimension(s.charAt(0));
			b = getDimension(s.charAt(1));
			c = getDimension(s.charAt(2));
			if (a <= volume.largeur && b <= volume.hauteur && c <= volume.profondeur) {
				v.add(new Volume(0, 0, 0, a, b, c));
				res = true;
			}
		}
		if (res) {
			Volume[] v_f = Tri_dimension((Volume[]) v.toArray(new Volume[v.size()]), dim_pref, "000");
			largeur = v_f[0].largeur;
			hauteur = v_f[0].hauteur;
			profondeur = v_f[0].profondeur;

		}

		return (res);
	}

	
	
	public static List<Volume> RegrouperVolumes(Volume[] libres)
	{
		List<Volume> newvolumes = new LinkedList<Volume>();
		boolean modification = true;
		
		if(libres.length==1 )
			newvolumes.add(libres[0]);
		
		Volume[] volumes = libres.clone();
		
		
		while(modification)
		{
			List<Volume> cotes1;
			modification = false;
			for(int i=0; i<volumes.length-1; i++)
			{
				int j = i+1;
				cotes1 = new LinkedList<Volume>();
				cotes1.add( new Volume(volumes[i].x, volumes[i].y, volumes[i].z,  volumes[i].largeur, volumes[i].hauteur, 0)    );
				
				cotes1.add( new Volume(volumes[i].x+volumes[i].largeur, volumes[i].y, volumes[i].z,  
						0, volumes[i].hauteur, volumes[i].profondeur)    );
				
				cotes1.add( new Volume(volumes[i].x, volumes[i].y, volumes[i].z+volumes[i].profondeur,  
						volumes[i].largeur, volumes[i].hauteur,0)    );
				
				cotes1.add( new Volume(volumes[i].x, volumes[i].y, volumes[i].z+volumes[i].profondeur,  
						0, volumes[i].hauteur,volumes[i].profondeur)    );
				
				cotes1.add( new Volume(volumes[i].x, volumes[i].y+volumes[i].hauteur, volumes[i].z,  
						volumes[i].largeur, 0,volumes[i].profondeur)    );
				
				cotes1.add( new Volume(volumes[i].x, volumes[i].y, volumes[i].z,  
						volumes[i].largeur, 0,volumes[i].profondeur)    );
				
				List<Volume> cotes2;
				
				boolean correspond = false;	
				while(!correspond && j<volumes.length)
				{
					cotes2 = new LinkedList<Volume>();
					cotes2.add( new Volume(volumes[j].x, volumes[j].y, volumes[j].z,  volumes[j].largeur, volumes[j].hauteur, 0)    );
					
					cotes2.add( new Volume(volumes[j].x+volumes[j].largeur, volumes[j].y, volumes[j].z,  
							0, volumes[j].hauteur, volumes[j].profondeur)    );
					
					cotes2.add( new Volume(volumes[j].x, volumes[j].y, volumes[j].z+volumes[j].profondeur,  
							volumes[j].largeur, volumes[j].hauteur,0)    );
					
					cotes2.add( new Volume(volumes[j].x, volumes[j].y, volumes[j].z+volumes[j].profondeur,  
							0, volumes[j].hauteur,volumes[j].profondeur)    );
					
					cotes2.add( new Volume(volumes[j].x, volumes[j].y+volumes[j].hauteur, volumes[j].z,  
							volumes[j].largeur, 0,volumes[j].profondeur)    );
					
					cotes2.add( new Volume(volumes[j].x, volumes[j].y, volumes[j].z,  
							volumes[j].largeur, 0,volumes[j].profondeur)    );
					
					for(Volume cote : cotes1)
						for(Volume cote2 : cotes2)
							if(!correspond && cote.x==cote2.x && cote2.y==cote.y && cote2.z==cote.z && 
									cote.largeur==cote2.largeur && cote2.hauteur==cote.hauteur && cote2.profondeur==cote.profondeur)
							{
								correspond=true;
								modification = true;
								Volume start = null;
								Volume end = null;
								for(char c : "xyz".toCharArray())
								{
									if(volumes[i].x<volumes[j].x)
									{
										start = volumes[i];
										end = volumes[j];
										break;
									}else if(volumes[i].x>volumes[j].x)
									{
										start = volumes[j];
										end = volumes[i];
										break;
									}
									else 
									{
										start = volumes[i];
										end = volumes[j];
									}
								}
								double largeur = start.largeur, hauteur=start.hauteur, profondeur=start.profondeur;
								if(start.x==end.x || start.y==end.y || start.z==end.z)
								{
									if(start.x==end.x)
										largeur = largeur+end.largeur;
									if(start.y==end.y)
										hauteur = hauteur+end.hauteur;
									if(start.z==end.z)
										profondeur = profondeur+end.profondeur;
								}		
								newvolumes.add(new Volume(start.x,start.y,start.z,largeur,hauteur,profondeur));

							}
					if(!correspond)
					{
						newvolumes.add(volumes[j]);
					}		

					j++;
				}
				if(!correspond)
				{
					newvolumes.add(volumes[i]);
				}		
				
					
				volumes = newvolumes.toArray(new Volume[newvolumes.size()]);
				newvolumes.clear();
				
			}
		}
		System.out.println(newvolumes.size());
		return newvolumes;
		
		
	}
	
}
